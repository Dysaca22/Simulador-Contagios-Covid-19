package Laboratorio.grafo;

import Laboratorio.Archivo;
import Laboratorio.grafo.arco.Arco;
import Laboratorio.grafo.nodo.Nodo;
import Laboratorio.visual.Panel;
import arraylist.ArrayList;
import java.awt.Point;

public class Grafo {

    private final ArrayList nodos;
    private final ArrayList arcos;
    private int numNodos;

    private int distancia;
    private final int ANCHO = 600;
    private final int MEDIONODO = 25;
    private final int RADIO = (ANCHO - MEDIONODO) / 2;
    private final Point CENTRO = new Point(MEDIONODO + RADIO, MEDIONODO + RADIO);

    private final ArrayList circunferencia;
    private final Panel panel;
    private final int opcionMascarilla;

    public Grafo(int numNodos, Panel panel, int opcionMascarilla) {
        this.panel = panel;
        this.opcionMascarilla = opcionMascarilla;
        circunferencia = new ArrayList();

        nodos = new ArrayList();
        arcos = new ArrayList();
        this.numNodos = numNodos;

        puntosdeCircunferencia();
        getDistacia();
    }

    private void puntosdeCircunferencia() {
        for (int i = MEDIONODO; i <= RADIO * 2 + MEDIONODO; i++) {
            for (int j = MEDIONODO; j <= RADIO * 2 + MEDIONODO; j++) {
                if (distanciaNodos(i, j, CENTRO.x, CENTRO.y) == RADIO) {
                    circunferencia.add(new Point(i, j));
                }
            }
        }
    }

    private void getDistacia() {
        if (numNodos < 19 && numNodos > 0) {
            int angulo = 360 / numNodos;
            distancia = (int) Math.ceil(2 * RADIO * Math.sin(Math.toRadians(angulo / 2)));
            inicializarNodos();
        }
    }

    private void inicializarNodos() {

        int x, y;
        do {
            x = (int) (Math.random() * (ANCHO - MEDIONODO) + MEDIONODO);
            y = (int) (Math.random() * (ANCHO - MEDIONODO) + MEDIONODO);
        } while (distanciaNodos(x, y, CENTRO.x, CENTRO.y) != RADIO);
        nodos.add(new Nodo(x, y, usoMascarilla()));
        numNodos--;

        while (numNodos != 0) {

            int i = 0;
            while (i < circunferencia.size()) {

                int puntoX = ((Point) circunferencia.get(i)).x;
                int puntoY = ((Point) circunferencia.get(i)).y;
                Nodo nodo = (Nodo) nodos.get(nodos.size() - 1);;

                if (isPosible(puntoX, puntoY, nodo) && isDiferente(puntoX, puntoY)) {

                    nodos.add(new Nodo(puntoX, puntoY, usoMascarilla()));
                    numNodos--;
                    i = circunferencia.size();
                }
                i++;
            }
        }
        inicializarAristas();
    }

    private boolean usoMascarilla() {
        switch (opcionMascarilla) {
            case 1:
                return true;
            case 2:
                return false;
            case 3:
                int num = (int) (Math.random() * 2 + 1);
                return num == 1;
        }
        return false;
    }

    private void inicializarAristas() {

        for (int i = 0; i < nodos.size(); i++) {
            int conexiones = (int) (Math.random() * (nodos.size() - 2) + 1);

            ArrayList numConexiones = new ArrayList();
            int l = 0;
            while (l < conexiones) {
                int nuevoNum;
                do {
                    nuevoNum = (int) (Math.random() * nodos.size());
                } while (nuevoNum == i);

                boolean sw = true;
                for (int k = 0; k < numConexiones.size(); k++) {
                    if ((int) numConexiones.get(k) == nuevoNum) {
                        sw = false;
                    }
                }
                if (sw) {
                    numConexiones.add(nuevoNum);
                    l++;
                }
            }

            Nodo nodo = (Nodo) nodos.get(i);
            for (int k = 0; k < numConexiones.size(); k++) {
                int peso = generarDistancia();
                nodo.addNodo((Nodo) nodos.get((int) numConexiones.get(k)), peso);
                arcos.add(new Arco(peso, nodo, (Nodo) nodos.get((int) numConexiones.get(k))));
            }
        }
        panel.start(nodos, arcos);
        Archivo.archivo(nodos);
    }

    private int generarDistancia() {
        return (int) (Math.random() * (4 - 1) + 1);
    }

    private boolean isDiferente(int x, int y) {

        for (int i = 0; i < nodos.size(); i++) {
            Nodo nodo = (Nodo) nodos.get(i);
            if (distanciaNodos(x, y, nodo.getPosicionX(), nodo.getPosicionY()) < distancia - 25) {
                return false;
            }
        }
        return true;
    }

    private boolean isPosible(int puntoX, int puntoY, Nodo nodo) {
        return distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia + 1
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia - 1
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia + 2
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia - 2
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia + 3
                || distanciaNodos(puntoX, puntoY, nodo.getPosicionX(), nodo.getPosicionY()) == distancia - 3;
    }

    private int distanciaNodos(int x1, int y1, int x2, int y2) {

        double distancia = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
        return (int) Math.ceil(distancia);
    }

}
