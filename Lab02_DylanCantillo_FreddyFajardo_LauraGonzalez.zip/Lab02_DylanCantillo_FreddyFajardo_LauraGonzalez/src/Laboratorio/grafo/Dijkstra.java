package Laboratorio.grafo;

import Laboratorio.grafo.nodo.Nodo;
import Laboratorio.lista.Elemento;
import arraylist.ArrayList;

public abstract class Dijkstra {

    public static ArrayList dijkstra(ArrayList nodos, Nodo nodoSeleccionado) {
        ArrayList ptr = new ArrayList();

        for (int i = 0; i < nodos.size(); i++) {
            if (ptr.size() == 0) {
                Lista p = new Lista();
                p.anterior = null;
                p.distancia = Integer.MAX_VALUE;
                ptr.add(p);
            } else {
                Lista q = new Lista();
                q.anterior = null;
                q.distancia = Integer.MAX_VALUE;
                ptr.add(q);
            }
        }
        int num = posicionNodo(nodoSeleccionado, nodos);
        Lista p = (Lista) ptr.get(num);
        p.anterior = nodoSeleccionado;
        p.distancia = 0;

        int repeticiones = 0;
        while (isEstablecido(ptr) && repeticiones <= nodos.size()) {
            Nodo nodo = getMejor(nodos, ptr);
            Elemento q = nodo.getListaADY().getPtr();
            while (q != null) {
                if (((Lista) ptr.get(posicionNodo(nodo, nodos))).distancia + q.peso
                        < ((Lista) ptr.get(posicionNodo(q.nodo, nodos))).distancia) {
                    ((Lista) ptr.get(posicionNodo(q.nodo, nodos))).distancia
                            = ((Lista) ptr.get(posicionNodo(nodo, nodos))).distancia + q.peso;
                    ((Lista) ptr.get(posicionNodo(q.nodo, nodos))).anterior = nodo;
                }
                q = q.link;
            }
            repeticiones++;
        }
        return ptr;
    }

    private static Nodo getMejor(ArrayList nodos, ArrayList ptr) {

        int menor = Integer.MAX_VALUE;;
        int posicion = 0;
        for (int i = 0; i < ptr.size(); i++) {
            Lista p = (Lista) ptr.get(i);
            if (!p.establecido && p.distancia < menor) {
                menor = p.distancia;
                posicion = i;
            }
        }
        Lista q = (Lista) ptr.get(posicion);
        q.establecido = true;
        return (Nodo) nodos.get(posicion);

    }

    private static boolean isEstablecido(ArrayList ptr) {
        for (int i = 0; i < ptr.size(); i++) {
            if (!((Lista) ptr.get(i)).establecido) {
                return true;
            }
        }
        return false;
    }

    public static class Lista {

        public Nodo anterior;
        public int distancia;
        public boolean establecido = false;
    }

    private static int posicionNodo(Nodo nodo, ArrayList nodos) {
        for (int i = 0; i < nodos.size(); i++) {
            if ((Nodo) nodos.get(i) == nodo) {
                return i;
            }
        }
        return 0;
    }
}
