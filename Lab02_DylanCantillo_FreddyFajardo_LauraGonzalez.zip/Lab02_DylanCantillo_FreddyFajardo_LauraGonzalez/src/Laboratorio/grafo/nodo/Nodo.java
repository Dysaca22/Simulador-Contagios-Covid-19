package Laboratorio.grafo.nodo;

import Laboratorio.lista.Elemento;
import Laboratorio.lista.Lista;
import java.awt.Color;
import java.awt.Graphics;

public class Nodo {

    private final int posicionX;
    private final int posicionY;
    private final boolean mascarilla;
    private boolean contagio;
    private boolean seleccionado;
    private final String nombre;

    private final Lista listaADY;
    public final int ANCHONODO = 50;

    public Nodo(int posicionX, int posicionY, boolean mascarilla) {
        listaADY = new Lista();

        String nom = "";
        do {
            nom = NombresNodos.escogerNombre((int) (Math.random() * NombresNodos.getTam()));
        } while (nom.length() >= 8);
        this.nombre = nom;

        contagio = false;
        this.posicionX = posicionX;
        this.posicionY = posicionY;
        this.mascarilla = mascarilla;
        seleccionado = false;
    }

    public void paint(Graphics g) {

        if (contagio) {
            g.setColor(Color.RED);
        } else {
            if (!seleccionado) {
                g.setColor(Color.WHITE);
            } else {
                g.setColor(Color.YELLOW);
            }
        }
        g.fillOval(posicionX - ANCHONODO / 2, posicionY - ANCHONODO / 2,
                ANCHONODO, ANCHONODO);
    }

    public void contagiar() {
        Elemento p = listaADY.getPtr();
        while (p != null) {
            if (!p.nodo.isContagio()) {
                metodoContagiar(this, p.nodo, p.peso);
            }
            p = p.link;
        }
    }

    private void metodoContagiar(Nodo contagiado,
            Nodo noContagado, int distancia) {
        int probabilidad = (int) (Math.random() * 100);

        if (!contagiado.isMascarilla()) {
            if (!noContagado.isMascarilla()) {
                if (distancia > 2) {
                    if (probabilidad <= 80) {
                        noContagado.setContagio();
                    }
                } else if (distancia <= 2) {
                    if (probabilidad <= 90) {
                        noContagado.setContagio();
                    }
                }
            } else {
                if (distancia > 2) {
                    if (probabilidad <= 40) {
                        noContagado.setContagio();
                    }
                } else if (distancia <= 2) {
                    if (probabilidad <= 60) {
                        noContagado.setContagio();
                    }
                }
            }
        } else {
            if (!noContagado.isMascarilla()) {
                if (distancia > 2) {
                    if (probabilidad <= 30) {
                        noContagado.setContagio();
                    }
                } else if (distancia <= 2) {
                    if (probabilidad <= 40) {
                        noContagado.setContagio();
                    }
                }
            } else {
                if (distancia > 2) {
                    if (probabilidad <= 20) {
                        noContagado.setContagio();
                    }
                } else if (distancia <= 2) {
                    if (probabilidad <= 30) {
                        noContagado.setContagio();
                    }
                }
            }
        }
    }

    public void addNodo(Nodo nodo, int peso) {
        listaADY.addNodo(nodo, peso);
    }

    public int getNumAdy() {
        return listaADY.getSize();
    }

    public Lista getListaADY() {
        return listaADY;
    }

    public int getPosicionX() {
        return posicionX;
    }

    public int getPosicionY() {
        return posicionY;
    }

    public boolean isMascarilla() {
        return mascarilla;
    }

    public boolean isContagio() {
        return contagio;
    }

    public void setSeleccionTrue() {
        seleccionado = true;
    }

    public void setSeleccionFalse() {
        seleccionado = false;
    }

    public void setContagio() {
        this.contagio = true;
    }

    public boolean isSeleccionado() {
        return seleccionado;
    }

    public String getNombre() {
        return nombre;
    }

}
