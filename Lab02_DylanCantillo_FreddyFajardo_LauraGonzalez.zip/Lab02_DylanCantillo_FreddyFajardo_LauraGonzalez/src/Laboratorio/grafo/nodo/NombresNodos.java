package Laboratorio.grafo.nodo;

import arraylist.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class NombresNodos {

    private static final ArrayList NOMBRES = leerNombres();

    public static int getTam() {
        return NOMBRES.size();
    }

    public static String escogerNombre(int num) {
        if (num < NOMBRES.size()) {
            return (String) NOMBRES.get(num);
        }
        return "";
    }

    private static ArrayList leerNombres() {
        File archivo = new File("Lista Nombres.txt");
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader rd = new BufferedReader(fr);
            return lectura(rd);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private static ArrayList lectura(BufferedReader rd) throws IOException {
        String linea;
        ArrayList a = new ArrayList();
        try {
            while ((linea = rd.readLine()) != null) {
                int i = 0;
                int ultimaComa = 0;
                while (i != linea.length()) {
                    if (linea.substring(i, i + 1).equals(",")) {
                        a.add(linea.substring(ultimaComa + 2, i));
                        ultimaComa = i;
                    }
                    i++;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        rd.close();
        return a;
    }
}
