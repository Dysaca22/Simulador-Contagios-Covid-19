package Laboratorio.grafo.arco;

import java.awt.Point;

public class Flecha {

    private final Point lineaP1;
    private final Point lineaP2;
    private Point arista1P, arista2P;

    private static final double DELTA = Math.PI / 4;
    private static final double LONGITUD = 10;

    public Flecha(Point lineaP1, Point lineaP2) {
        this.lineaP1 = lineaP1;
        this.lineaP2 = lineaP2;
        arista1P = new Point();
        arista2P = new Point();

        calcularFlecha();
    }

    public void calcularFlecha() {

        Point ajustadas = trasladarFigura(lineaP2.x, lineaP2.y);
        Point cateto = calcularCateto(ajustadas.x, ajustadas.y);
        Point factor = calcularFactor(ajustadas.x, ajustadas.y);
        double xp = lineaP1.x + (factor.x * cateto.x);
        double yp = lineaP1.y + (factor.y * cateto.y);
        ajustadas = trasladarFigura(xp, yp);
        arista1P = rotacionHoraria(ajustadas.x, ajustadas.y);
        arista2P = rotacionAntiHorario(ajustadas.x, ajustadas.y);
    }

    private Point trasladarFigura(double x, double y) {
        double xp = x - lineaP1.x;
        double yp = lineaP1.y - y;
        return new Point((int) xp, (int) yp);
    }

    private Point calcularCateto(double x, double y) {
        double angulo = Math.atan(y / x);
        double a = Math.sqrt(Math.pow(LONGITUD, 2)
                / (1 + Math.pow(Math.tan(angulo), 2)));
        double b = Math.sqrt(Math.pow(LONGITUD, 2) - Math.pow(a, 2));
        return new Point((int) a, (int) b);
    }

    private Point calcularFactor(double x, double y) {
        double fx = x / Math.abs(x);
        double fy = y / (Math.abs(y) * -1);
        return new Point((int) fx, (int) fy);
    }

    private Point rotacionHoraria(double x, double y) {
        double xp = x * Math.cos(DELTA) + y * Math.sin(DELTA);
        double yp = (-1 * x * Math.sin(DELTA)) + y * Math.cos(DELTA);
        xp = lineaP1.x + xp;
        yp = lineaP1.y - yp;
        return new Point((int) xp, (int) yp);
    }

    private Point rotacionAntiHorario(double x, double y) {
        double xp = x * Math.cos(DELTA) + (-1 * y * Math.sin(DELTA));
        double yp = x * Math.sin(DELTA) + y * Math.cos(DELTA);
        xp = lineaP1.x + xp;
        yp = lineaP1.y - yp;
        return new Point((int) xp, (int) yp);
    }

    public Point getLineaP1() {
        return lineaP1;
    }

    public Point getLineaP2() {
        return lineaP2;
    }

    public Point getArista1P() {
        return arista1P;
    }

    public Point getArista2P() {
        return arista2P;
    }

}
