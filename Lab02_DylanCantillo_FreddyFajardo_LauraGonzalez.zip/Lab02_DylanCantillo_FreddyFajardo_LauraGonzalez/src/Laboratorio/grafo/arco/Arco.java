package Laboratorio.grafo.arco;

import Laboratorio.grafo.nodo.Nodo;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

public class Arco {

    private final int PESO;
    private final Nodo nodoOrigen;
    private final Nodo nodoLlegada;

    private boolean seleccionado;
    private boolean rutaContagio;

    private final Flecha flecha;

    private final int X1;
    private final int Y1;
    private int X2;
    private int Y2;

    public Arco(int peso, Nodo nodoOrigen, Nodo nodoLlegada) {

        this.PESO = peso;
        this.nodoOrigen = nodoOrigen;
        this.nodoLlegada = nodoLlegada;
        seleccionado = false;
        rutaContagio = false;

        X1 = nodoOrigen.getPosicionX();
        Y1 = nodoOrigen.getPosicionY();
        X2 = nodoLlegada.getPosicionX();
        Y2 = nodoLlegada.getPosicionY();

        reducirArcos();
        flecha = new Flecha(new Point(X2, Y2), new Point(X1, Y1));
    }

    private void reducirArcos() {

        double distancia = Math.sqrt(Math.pow(X1 - X2, 2) + Math.pow(Y1 - Y2, 2));
        double factor = (nodoLlegada.ANCHONODO / 2) * Math.pow(distancia, -1);
        X2 = (int) (X2 + factor * (X1 - X2));
        Y2 = (int) (Y2 + factor * (Y1 - Y2));

    }

    public void paint(Graphics g) {

        if (rutaContagio) {
            escribirPeso(g);
            g.setColor(Color.RED);
        } else {
            if (seleccionado) {
                escribirPeso(g);
                g.setColor(Color.YELLOW);
            } else {
                g.setColor(Color.PINK);
            }
        }
        g.drawLine(flecha.getLineaP1().x, flecha.getLineaP1().y,
                flecha.getArista1P().x, flecha.getArista1P().y);
        g.drawLine(flecha.getLineaP1().x, flecha.getLineaP1().y,
                flecha.getArista2P().x, flecha.getArista2P().y);
        g.drawLine(X1, Y1, X2, Y2);
    }

    private void escribirPeso(Graphics g) {

        g.setColor(Color.WHITE);
        int x;
        int y;

        int division;
        int distancia = (int) Math.sqrt(Math.pow(X1 - X2, 2) + Math.pow(Y1 - Y2, 2));
        if (distancia <= 200) {
            division = 5;
        } else {
            division = 8;
        }

        if (X2 > X1) {
            x = X2 - (X2 - X1) / division;
        } else if (X1 > X2) {
            x = X2 + (X1 - X2) / division;
        } else {
            x = X2;
        }

        if (Y2 > Y1) {
            y = Y2 - (Y2 - Y1) / division;
        } else if (Y1 > Y2) {
            y = Y2 + (Y1 - Y2) / division;
        } else {
            y = Y2 - 8;
            x = x + 8;
        }

        if (X2 > X1 && Y2 < Y1) {
            x = x - 8;
        } else if (X2 < X1 && Y2 > Y1) {
            x = x + 8;
            y = y + 8;
        } else {
            y = y - 8;
        }
        g.drawString(PESO + "", x, y);
    }

    public boolean isRutaContagio() {
        return rutaContagio;
    }

    public Nodo getNodoOrigen() {
        return nodoOrigen;
    }

    public Nodo getNodoLlegada() {
        return nodoLlegada;
    }

    public int getPeso() {
        return PESO;
    }

    public void setSeleccionTrue() {
        seleccionado = true;
    }

    public void setSeleccionFalse() {
        seleccionado = false;
    }

    public void setRutaContagioTrue() {
        rutaContagio = true;
    }

    public void setRutaContagioFalse() {
        rutaContagio = false;
    }

}
