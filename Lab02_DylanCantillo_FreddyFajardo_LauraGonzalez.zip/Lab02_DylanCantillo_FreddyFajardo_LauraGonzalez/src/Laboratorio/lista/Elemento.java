package Laboratorio.lista;

import Laboratorio.grafo.nodo.Nodo;

public class Elemento {

    public Nodo nodo;
    public Elemento link;
    public int peso;

}
