package Laboratorio.lista;

import Laboratorio.grafo.nodo.Nodo;

public class Lista {

    private Elemento ptr;

    public Lista() {
        ptr = null;
    }

    private Elemento addElemento(Elemento ptr, Nodo info, int peso) {

        Elemento p = ptr;
        Elemento q = new Elemento();
        q.nodo = info;
        q.peso = peso;

        if (ptr == null) {
            ptr = q;

        } else {
            while (p.link != null) {
                p = p.link;
            }
            p.link = q;
        }
        return ptr;
    }

    public Nodo getNodo(int i) {
        int num = 0;
        Elemento p = ptr;
        while (p.link != null && num != i) {
            num++;
            p = p.link;
        }
        return p.nodo;
    }

    public int getSize() {
        int size = 0;
        Elemento p = ptr;
        while (p != null) {
            size++;
            p = p.link;
        }
        return size;
    }

    public void addNodo(Nodo nodo, int peso) {
        ptr = addElemento(ptr, nodo, peso);
    }

    public Elemento getPtr() {
        return ptr;
    }

    public Nodo getUltimoNodo() {
        Elemento p = this.getPtr();
        while (p.link != null) {
            p = p.link;
        }
        return p.nodo;
    }

}
