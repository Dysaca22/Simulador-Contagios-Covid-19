package Laboratorio.visual;

import Laboratorio.grafo.Grafo;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class VentanaPrincipal extends javax.swing.JFrame {

    private static final int ANCHO = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
    private static final int ALTO = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

    public VentanaPrincipal() {
        initComponents();
        this.setSize(867, 518);
        this.getContentPane().setBackground(Color.DARK_GRAY);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        GrupoBotones = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        numNodos = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        mascarilla = new javax.swing.JRadioButton();
        noMascarilla = new javax.swing.JRadioButton();
        aleatorio = new javax.swing.JRadioButton();
        salir = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        minimizar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Agency FB", 1, 55)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Simulador de Contagio");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(130, 20, 590, 140);

        jLabel2.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("<html> <p style=”text-align: center;”> Número de personas para la simulación </p> </html>");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(340, 180, 180, 70);
        getContentPane().add(numNodos);
        numNodos.setBounds(340, 260, 179, 40);

        jButton1.setBackground(new java.awt.Color(10, 7, 114));
        jButton1.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Generar");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(380, 380, 100, 75);

        GrupoBotones.add(mascarilla);
        mascarilla.setForeground(new java.awt.Color(255, 255, 255));
        mascarilla.setText("Mascarilla");
        mascarilla.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(mascarilla);
        mascarilla.setBounds(270, 330, 80, 23);

        GrupoBotones.add(noMascarilla);
        noMascarilla.setForeground(new java.awt.Color(255, 255, 255));
        noMascarilla.setText("Sin mascarilla");
        noMascarilla.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(noMascarilla);
        noMascarilla.setBounds(380, 330, 110, 23);

        GrupoBotones.add(aleatorio);
        aleatorio.setForeground(new java.awt.Color(255, 255, 255));
        aleatorio.setText("Aleatorio");
        aleatorio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(aleatorio);
        aleatorio.setBounds(520, 330, 80, 23);

        salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/botonSalir.png"))); // NOI18N
        salir.setToolTipText("Salir");
        salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salirMouseClicked(evt);
            }
        });
        getContentPane().add(salir);
        salir.setBounds(850, 0, 16, 16);

        jLabel4.setFont(new java.awt.Font("Agency FB", 1, 55)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(10, 7, 114));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Simulador de Contagio");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(140, 30, 590, 140);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/RRRR.png"))); // NOI18N
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 450, 190, 70);

        minimizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/botonMinimizar.png"))); // NOI18N
        minimizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        minimizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimizarMouseClicked(evt);
            }
        });
        getContentPane().add(minimizar);
        minimizar.setBounds(830, 0, 16, 16);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/MarcaFondo.png"))); // NOI18N
        getContentPane().add(jLabel3);
        jLabel3.setBounds(-480, -290, 1350, 810);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        boolean sw = true;
        int opcion = 0;
        if (mascarilla.isSelected()) {
            opcion = 1;
        } else if (noMascarilla.isSelected()) {
            opcion = 2;
        } else if (aleatorio.isSelected()) {
            opcion = 3;
        } else {
            sw = false;
        }
        if (sw) {
            String numeroNodos = numNodos.getText();
            int num;
            try {
                num = Integer.parseInt(numeroNodos);
                if (num >= 2 && num <= 18) {

                    JFrame ventana = new JFrame("Simulador");
                    Panel panel = new Panel(ventana);
                    Grafo grafo = new Grafo(num, panel, opcion);

                    ventana.add(panel);
                    ventana.setSize(ANCHO, ALTO);
                    ventana.setUndecorated(true);
                    ventana.setLocationRelativeTo(null);
                    ventana.setVisible(true);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Introduce un valor mayor que 1 y menor que 19");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Introduce un valor numerico");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un uso de mascarilla");
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void salirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salirMouseClicked

        int salir = JOptionPane.showOptionDialog(null, "¿Seguro deseas salir?", "Salir",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                new Object[]{"Si", "No"}, "No");

        if (JOptionPane.OK_OPTION == salir) {
            System.exit(0);
        }
    }//GEN-LAST:event_salirMouseClicked

    private void minimizarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizarMouseClicked
        this.setExtendedState(1);
    }//GEN-LAST:event_minimizarMouseClicked

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup GrupoBotones;
    private javax.swing.JRadioButton aleatorio;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JRadioButton mascarilla;
    private javax.swing.JLabel minimizar;
    private javax.swing.JRadioButton noMascarilla;
    private javax.swing.JTextField numNodos;
    private javax.swing.JLabel salir;
    // End of variables declaration//GEN-END:variables
}
