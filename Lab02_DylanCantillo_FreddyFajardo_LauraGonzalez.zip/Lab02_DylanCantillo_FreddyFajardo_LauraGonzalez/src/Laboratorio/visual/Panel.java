package Laboratorio.visual;

import Laboratorio.grafo.Dijkstra;
import Laboratorio.grafo.arco.Arco;
import Laboratorio.grafo.nodo.Nodo;
import arraylist.ArrayList;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Panel extends JPanel {

    private static final int ANCHO = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
    private static final int ALTO = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

    private ArrayList nodos;
    private ArrayList arcos;

    private JLabel fondo;
    private JLabel marco;
    private JButton salir;
    private JButton minimizar;
    private JButton iteracion;
    private JButton nuevo;
    private JButton dijkstra;

    private final JFrame ventana;
    public ArrayList objetos;

    private boolean seleccion = false;
    private int numIteraciones = 0;
    private Nodo nodoSeleccionado;

    private final int PUNTOX = 3 * ANCHO / 4;
    private final int PUNTOY = 150;

    public Panel(JFrame ventana) {
        initComponents();

        nodos = new ArrayList();
        arcos = null;

        this.ventana = ventana;
        objetos = new ArrayList();

        this.addMouseListener(new MouseListener());
        this.setBackground(Color.BLACK);
        this.setLayout(null);
        this.setVisible(true);
    }

    private void initComponents() {

        marco = new JLabel();
        this.add(marco);
        ImageIcon marcoIcon = new ImageIcon(getClass().getResource("/Imagenes/marco.png"));
        marco.setIcon(marcoIcon);
        marco.setBounds(PUNTOX - 185, PUNTOY - 30, marcoIcon.getIconWidth(), marcoIcon.getIconHeight());

        salir = new JButton();
        this.add(salir);
        ImageIcon icon = new ImageIcon(getClass().getResource("/Imagenes/botonSalir.png"));
        salir.setIcon(icon);
        salir.addActionListener(new BotonPulsadoSalir());
        salir.setBounds(ANCHO - icon.getIconWidth() - 4, 0, icon.getIconWidth(), icon.getIconHeight());
        salir.setBorder(null);
        salir.setContentAreaFilled(false);
        salir.setCursor(Cursor.getPredefinedCursor(12));
        salir.setFocusable(false);

        minimizar = new JButton();
        this.add(minimizar);
        ImageIcon iconM = new ImageIcon(getClass().getResource("/Imagenes/botonMinimizar.png"));
        minimizar.setIcon(iconM);
        minimizar.addActionListener(new BotonPulsadoMinimizar());
        minimizar.setBounds(ANCHO - iconM.getIconWidth() - salir.getWidth() - 7, 0, iconM.getIconWidth(), iconM.getIconHeight());
        minimizar.setBorder(null);
        minimizar.setContentAreaFilled(false);
        minimizar.setCursor(Cursor.getPredefinedCursor(12));
        minimizar.setFocusable(false);

        iteracion = new JButton();
        this.add(iteracion);
        ImageIcon icon2 = new ImageIcon(getClass().getResource("/Imagenes/botonIteracion.png"));
        iteracion.setIcon(icon2);
        iteracion.addActionListener(new BotonPulsadoIteracion());
        iteracion.setBounds(PUNTOX - icon2.getIconWidth() / 2, ALTO * 3 / 4, icon2.getIconWidth() + 5, icon2.getIconHeight() + 20);
        iteracion.setText("Iteración");
        iteracion.setFont(new Font("Agency FB", Font.BOLD, 22));
        iteracion.setForeground(Color.WHITE);
        iteracion.setVerticalTextPosition(3);
        iteracion.setHorizontalTextPosition(0);
        iteracion.setBorder(null);
        iteracion.setContentAreaFilled(false);
        iteracion.setCursor(Cursor.getPredefinedCursor(12));
        iteracion.setFocusable(false);

        nuevo = new JButton();
        this.add(nuevo);
        ImageIcon iconNu = new ImageIcon(getClass().getResource("/Imagenes/botonNuevo.png"));
        nuevo.setIcon(iconNu);
        nuevo.addActionListener(new BotonPulsadoNuevo());
        nuevo.setBounds(0, ALTO - iconNu.getIconHeight() - 25, iconNu.getIconWidth() * 2, iconNu.getIconHeight() + 20);
        nuevo.setText("Nueva Simulación");
        nuevo.setFont(new Font("Agency FB", Font.BOLD, 22));
        nuevo.setForeground(Color.WHITE);
        nuevo.setVerticalTextPosition(1);
        nuevo.setHorizontalTextPosition(0);
        nuevo.setBorder(null);
        nuevo.setContentAreaFilled(false);
        nuevo.setCursor(Cursor.getPredefinedCursor(12));
        nuevo.setFocusable(false);

        dijkstra = new JButton();
        this.add(dijkstra);
        ImageIcon icon3 = new ImageIcon(getClass().getResource("/Imagenes/botonRuta.png"));
        dijkstra.setIcon(icon3);
        dijkstra.addActionListener(new BotonPulsadoDijkstra());
        dijkstra.setBounds(marco.getX() + marco.getWidth() - icon3.getIconWidth(), marco.getY() + marco.getHeight() - icon3.getIconHeight(),
                icon3.getIconWidth(), icon3.getIconHeight());
        dijkstra.setToolTipText("Ruta de contagio");
        dijkstra.setBorder(null);
        dijkstra.setContentAreaFilled(false);
        dijkstra.setCursor(Cursor.getPredefinedCursor(12));
        dijkstra.setFocusable(false);
        dijkstra.setVisible(false);

        fondo = new JLabel();
        this.add(fondo);
        fondo.setBounds(0, 0, ANCHO, ALTO);
        ImageIcon icon1 = new ImageIcon(getClass().getResource("/Imagenes/MarcaFondo.png"));
        fondo.setIcon(icon1);
    }

    public void start(ArrayList nodos, ArrayList arcos) {
        this.nodos = nodos;
        rellenarObjetos();
        this.arcos = arcos;
        repaint();
    }

    private void rellenarObjetos() {

        for (int i = 0; i < nodos.size(); i++) {
            Nodo nodo = (Nodo) nodos.get(i);
            Rectangle r = new Rectangle(nodo.getPosicionX() - 25,
                    nodo.getPosicionY() - 25, nodo.ANCHONODO, nodo.ANCHONODO);
            objetos.add(r);
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if (nodos.size() != 0) {

            ArrayList arcosRuta = comprobarRuta();
            if (arcosRuta.size() != 0) {
                for (int i = 0; i < arcosRuta.size(); i++) {
                    Arco a = (Arco) arcosRuta.get(i);
                    a.paint(g);
                }
            } else {

                ArrayList arcosSeleccionados = comprobarSeleccion();
                if (arcosSeleccionados.size() != 0) {
                    for (int i = 0; i < arcosSeleccionados.size(); i++) {
                        Arco a = (Arco) arcosSeleccionados.get(i);
                        a.paint(g);
                    }
                } else {

                    for (int i = 0; i < arcos.size(); i++) {
                        Arco arco = (Arco) arcos.get(i);
                        arco.paint(g);
                    }
                }
            }

            for (int i = 0; i < nodos.size(); i++) {
                Nodo nodo = (Nodo) nodos.get(i);
                nodo.paint(g);
            }
        }

        g.setColor(Color.WHITE);

        g.setFont(new Font("Arial", Font.BOLD, 15));
        int ancho = 370;
        int x = PUNTOX - ancho / 2;
        int y = PUNTOY;

        int auxX = x + 30;
        int auxY = 200 / 5;
        g.drawString("Información de la Persona", x + ancho / 2 - medirAnchoPixeles(g, "Información de la Persona") / 2, y + auxY);
        g.drawString("Nombre: ", auxX, y + auxY * 2);
        g.drawString("Usa mascarilla: ", auxX, y + auxY * 3);
        g.drawString("Esta contagiado: ", auxX, y + auxY * 4);
        int auxX2;

        if (seleccion) {
            if (nodoSeleccionado.isContagio()) {
                g.drawString("Puede infectar a: ", auxX, y + auxY * 5);
                auxX2 = x + 30 + medirAnchoPixeles(g, "Puede invectar a: " + 20);
            } else {
                g.drawString("Esta conectado con: ", auxX, y + auxY * 5);
                auxX2 = x + 30 + medirAnchoPixeles(g, "Esta conectado con: " + 20);
            }

            g.drawString(nodoSeleccionado.getNombre(), auxX2, y + auxY * 2);
            if (nodoSeleccionado.isMascarilla()) {
                g.drawString("Si", auxX2, y + auxY * 3);
            } else {
                g.drawString("No", auxX2, y + auxY * 3);
            }
            if (nodoSeleccionado.isContagio()) {
                g.drawString("Si", auxX2, y + auxY * 4);
            } else {
                g.drawString("No", auxX2, y + auxY * 4);
            }
            g.drawString("" + nodoSeleccionado.getNumAdy(), auxX2, y + auxY * 5);
        } else {
            g.setColor(Color.BLACK);
        }
    }

    private int medirAnchoPixeles(final Graphics g, String palabra) {
        FontMetrics fm = g.getFontMetrics();
        return fm.stringWidth(palabra);
    }

    private ArrayList comprobarSeleccion() {
        ArrayList aux = new ArrayList();

        for (int i = 0; i < nodos.size(); i++) {
            Nodo nodo = (Nodo) nodos.get(i);
            if (nodo.isSeleccionado()) {
                for (int j = 0; j < arcos.size(); j++) {
                    Arco arco = (Arco) arcos.get(j);
                    if (arco.getNodoOrigen() == nodo) {
                        arco.setSeleccionTrue();
                        aux.add(arco);
                    }
                }
            }
        }

        return aux;
    }

    private ArrayList comprobarRuta() {
        ArrayList aux = new ArrayList();
        for (int i = 0; i < arcos.size(); i++) {
            Arco arco = (Arco) arcos.get(i);
            if (arco.isRutaContagio()) {
                aux.add(arco);
            }
        }

        return aux;

    }

    private class BotonPulsadoSalir implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int volver = JOptionPane.showOptionDialog(null, "¿Seguro deseas salir?", "Salir",
                    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                    new Object[]{"Si", "No"}, "No");

            if (JOptionPane.OK_OPTION == volver) {
                System.exit(0);
            }
        }
    }

    private class BotonPulsadoMinimizar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            ventana.setExtendedState(1);
        }
    }

    private class BotonPulsadoNuevo implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            VentanaPrincipal vp = new VentanaPrincipal();
            ventana.dispose();
        }
    }

    private class BotonPulsadoDijkstra implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < arcos.size(); i++) {
                Arco arco = (Arco) arcos.get(i);
                arco.setSeleccionFalse();
                arco.setRutaContagioFalse();
            }

            if (!nodoSeleccionado.isContagio()) {

                int menorDistancia = Integer.MAX_VALUE;
                int numNodoMenor = 0;
                for (int i = 0; i < nodos.size(); i++) {
                    if (((Nodo) nodos.get(i)).isContagio()) {
                        ArrayList recorridoAux = Dijkstra.dijkstra(nodos, (Nodo) nodos.get(i));
                        if (((Dijkstra.Lista) recorridoAux.get(posicionNodo(nodoSeleccionado))).distancia < menorDistancia) {
                            menorDistancia = ((Dijkstra.Lista) recorridoAux.get(posicionNodo(nodoSeleccionado))).distancia;
                            numNodoMenor = i;
                        }
                    }
                }

                ArrayList recorrido = Dijkstra.dijkstra(nodos, (Nodo) nodos.get(numNodoMenor));

                ArrayList nodosRuta = new ArrayList();
                Nodo ultimoNodo = (Nodo) nodos.get(posicionNodo(nodoSeleccionado));
                nodosRuta.add(ultimoNodo);
                do {
                    ultimoNodo = ((Dijkstra.Lista) recorrido.get(posicionNodo(ultimoNodo))).anterior;
                    nodosRuta.add(ultimoNodo);
                } while (ultimoNodo != nodos.get(numNodoMenor));

                boolean tieneRuta = false;
                for (int j = 0; j < arcos.size(); j++) {
                    Arco arco = (Arco) arcos.get(j);
                    for (int i = nodosRuta.size() - 1; i >= 0; i--) {
                        if (arco.getNodoOrigen() == ((Nodo) nodosRuta.get(i + 1)) && arco.getNodoLlegada() == ((Nodo) nodosRuta.get(i))) {
                            arco.setRutaContagioTrue();
                            tieneRuta = true;
                        }
                    }
                }

                if (!tieneRuta) {
                    JOptionPane.showMessageDialog(null, "No existe ruta de contagio hacia " + nodoSeleccionado.getNombre());
                }

                repaint();
            } else {
                JOptionPane.showMessageDialog(null, nodoSeleccionado.getNombre() + " ya esta contagiado");
            }
        }

        private int posicionNodo(Nodo nodo) {
            for (int i = 0; i < nodos.size(); i++) {
                if ((Nodo) nodos.get(i) == nodo) {
                    return i;
                }
            }
            return 0;
        }
    }

    private class BotonPulsadoIteracion implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            boolean completado = false;
            for (int i = 0; i < nodos.size(); i++) {
                if (!((Nodo) nodos.get(i)).isContagio()) {
                    completado = true;
                }
            }
            if (completado) {

                if (numIteraciones == 0) {
                    int numNodo = (int) (Math.random() * nodos.size());
                    ((Nodo) nodos.get(numNodo)).setContagio();
                } else {
                    ArrayList nodosContagiados = new ArrayList();
                    for (int i = 0; i < nodos.size(); i++) {
                        Nodo nodo = (Nodo) nodos.get(i);
                        if (nodo.isContagio()) {
                            nodosContagiados.add(i);
                        }
                    }
                    for (int i = 0; i < nodosContagiados.size(); i++) {
                        ((Nodo) nodos.get((int) nodosContagiados.get(i))).contagiar();
                    }
                }
                numIteraciones++;
                iteracion.setText("Iteración #" + numIteraciones);
                repaint();
            } else {
                JOptionPane.showMessageDialog(null, "Ya todos las personas estan contagiadas");
            }
        }
    }

//Clase MouseListener
    public class MouseListener implements java.awt.event.MouseListener {

        @Override
        public void mouseClicked(MouseEvent me) {
        }

        @Override
        public void mousePressed(MouseEvent me) {

            if (objetos.size() != 0) {
                ArrayList rects = objetos;

                Point punto = MouseInfo.getPointerInfo().getLocation();
                Rectangle r = new Rectangle(punto.x, punto.y, 1, 1);

                seleccion = false;
                dijkstra.setVisible(false);
                for (int i = 0; i < rects.size(); i++) {
                    Rectangle rect = (Rectangle) rects.get(i);
                    ((Nodo) nodos.get(i)).setSeleccionFalse();
                    if (r.intersects(rect)) {
                        ((Nodo) nodos.get(i)).setSeleccionTrue();
                        nodoSeleccionado = (Nodo) nodos.get(i);
                        seleccion = true;
                        if (numIteraciones > 0) {
                            dijkstra.setVisible(true);
                        }
                    }
                }

                for (int i = 0; i < arcos.size(); i++) {
                    Arco arco = (Arco) arcos.get(i);
                    arco.setSeleccionFalse();
                    arco.setRutaContagioFalse();
                }

                repaint();
            }
        }

        @Override
        public void mouseReleased(MouseEvent me) {
        }

        @Override
        public void mouseEntered(MouseEvent me) {

        }

        @Override
        public void mouseExited(MouseEvent me) {
        }

    }

}
