package Laboratorio;

import Laboratorio.grafo.nodo.Nodo;
import Laboratorio.lista.Elemento;
import arraylist.ArrayList;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Archivo {

    public static void archivo(ArrayList nodos) {
        BufferedWriter bw = null;
        FileWriter fw = null;

        try {
            String data;
            File file = new File("Grafo.txt");
            if (!file.exists()) {
                file.createNewFile();
                data = escribir(nodos, true);
            } else {
                data = escribir(nodos, false);
            }
            fw = new FileWriter(file.getAbsoluteFile(), true);
            bw = new BufferedWriter(fw);
            bw.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null) {
                    bw.close();
                }
                if (fw != null) {
                    fw.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    private static String escribir(ArrayList nodos, boolean primera) {
        StringBuilder sb = new StringBuilder();
        if (!primera) {
            sb.append("\n");
            sb.append("\n");
            sb.append("_________________________________________________________");
            sb.append("\n");
        }

        sb.append("Lista de adyacencia del grafo");
        sb.append("\n");
        sb.append("\n");
        for (int i = 0; i < nodos.size(); i++) {
            Nodo nodo = (Nodo) nodos.get(i);
            sb.append(nodo.getNombre()).append("_").append(i);
            Elemento p = nodo.getListaADY().getPtr();
            while (p != null) {
                sb.append("   --->   ").append(p.nodo.getNombre());
                p = p.link;
            }
            sb.append("   --->   ").append("/");
            sb.append("\n");
            sb.append(" |");
            sb.append("\n");
            sb.append(" |");
            sb.append("\n");
            sb.append(" V");
            sb.append("\n");
            if (i == nodos.size() - 1) {
                sb.append(" /");
            }
        }
        return sb.toString();
    }
}
