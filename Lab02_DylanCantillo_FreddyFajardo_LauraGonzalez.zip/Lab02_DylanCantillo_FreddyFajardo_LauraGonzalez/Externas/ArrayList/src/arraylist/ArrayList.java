package arraylist;

public class ArrayList {

    private Elemento ptr;

    public ArrayList() {
        ptr = null;
    }

    private Elemento addElemento(Elemento ptr,
            Object info) {

        Elemento p = ptr;
        Elemento q = new Elemento();

        q.info = info;
        if (ptr == null) {
            ptr = q;

        } else {
            while (p.Link != null) {
                p = p.Link;
            }
            p.Link = q;
        }
        return ptr;
    }

    public void add(Object elemento) {
        ptr = addElemento(ptr, elemento);
    }

    public Object get(int i) {
        int cont = 0;
        Elemento p = ptr;

        while (p != null) {
            if (i == cont) {
                return p.info;
            } else {
                p = p.Link;
                cont++;
            }
        }

        return null;
    }

    public int size() {
        int tam = 0;
        Elemento p = ptr;

        while (p != null) {
            p = p.Link;
            tam++;
        }

        return tam;
    }

}
