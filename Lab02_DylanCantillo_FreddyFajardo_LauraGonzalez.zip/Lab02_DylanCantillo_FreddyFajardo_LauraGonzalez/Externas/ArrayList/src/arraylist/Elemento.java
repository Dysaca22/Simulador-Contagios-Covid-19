package arraylist;

public class Elemento {

    Object info;
    Elemento Link;

}
